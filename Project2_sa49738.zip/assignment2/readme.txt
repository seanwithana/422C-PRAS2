Welcome to Mastermind!!!

This program simulates a text-based version of the baord game called Mastermind.

Details about the game can be found here
http://en.wikipedia.org/wiki/Mastermind_(board_game)


The program is broken up into multiple classes to demonstrated an OOP approach.

Compiling/Running the Driver.java file will get the game started. The first command line arg specifies
whether to play the game in testing mode, where it shows the secret code to be guessed.

arg[0] = 1 for testing mode
arg[0] = anything else for non-testing mode